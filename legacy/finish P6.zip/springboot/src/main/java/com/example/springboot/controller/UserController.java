package com.example.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.springboot.entity.User;
import com.example.springboot.mapper.UserMapper;

@RestController
public class UserController{

    @Autowired //无需构造方法自动注入
	private UserMapper userMapper;

    @GetMapping("/")
	public List<User> index(){
        // return userMapper.findAll();
        List<User> all = userMapper.findAll();
		return all;
	}

}